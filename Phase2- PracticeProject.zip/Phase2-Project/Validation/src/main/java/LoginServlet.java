import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Hard-coded valid credentials
    private static final String VALID_EMAIL = "user@gmail.com";
    private static final String VALID_PASSWORD = "pass123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user input
        String userEmail = request.getParameter("email");
        String userPassword = request.getParameter("password");

        // Validate user credentials
        if (VALID_EMAIL.equals(userEmail) && VALID_PASSWORD.equals(userPassword)) {
            // Valid login, create a session
            HttpSession session = request.getSession();
            session.setAttribute("userEmail", userEmail);

            // Redirect to the dashboard
            response.sendRedirect("DashboardServlet");
        } else {
            // Invalid login, show error message
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>Login Error</title></head><body>");
            out.println("<h2>Invalid credentials. Please try again.</h2>");
            out.println("<a href='index.html'>Go back to login</a>");
            out.println("</body></html>");
        }
    }
}

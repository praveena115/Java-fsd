import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if the user is logged in (session exists)
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("userEmail") != null) {
            // User is logged in, show the dashboard
            String userEmail = (String) session.getAttribute("userEmail");

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><head><title>Dashboard</title></head><body>");
            out.println("<h2>Welcome to the Dashboard, " + userEmail + "!</h2>");
            out.println("<a href='LogoutServlet'>Logout</a>");
            out.println("</body></html>");
        } else {
            // User is not logged in, redirect to the login page
            response.sendRedirect("index.html");
        }
    }
}

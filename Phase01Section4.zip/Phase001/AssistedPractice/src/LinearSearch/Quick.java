package LinearSearch;
import java.util.Scanner;

public class Quick {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Input array elements
        System.out.println("Enter the elements of the array:");
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.println("\nOriginal Array:");
        printArray(array);

        // Perform Quick Sort
        quickSort(array, 0, size - 1);

        System.out.println("\nArray after Quick Sort:");
        printArray(array);

        scanner.close();
    }

    private static void quickSort(int[] array, int low, int high) {
        if (low < high) {
            // Find the pivot index such that elements smaller than the pivot are on the left, and greater on the right
            int pivotIndex = partition(array, low, high);

            // Recursively sort the subarrays on the left and right of the pivot
            quickSort(array, low, pivotIndex - 1);
            quickSort(array, pivotIndex + 1, high);
        }
    }

    private static int partition(int[] array, int low, int high) {
        int pivot = array[high];
        int i = low - 1;

        // Rearrange elements such that elements smaller than the pivot are on the left, and greater on the right
        for (int j = low; j < high; j++) {
            if (array[j] <= pivot) {
                i++;
                swap(array, i, j);
            }
        }

        // Place the pivot element in its correct position
        swap(array, i + 1, high);

        return i + 1;
    }

    private static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    private static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}



package LinearSearch;
import java.util.Arrays;
import java.util.Scanner;

public class Exponential {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array elements (assuming the array is sorted)
        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();
        int[] array = new int[size];

        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Input the element to search
        System.out.print("Enter the element to search: ");
        int target = scanner.nextInt();

        // Perform exponential search
        int index = exponentialSearch(array, target);

        // Display the result
        if (index >= 0) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found in the array");
        }

        scanner.close();
    }

    // Exponential Search Algorithm
    private static int exponentialSearch(int[] array, int target) {
        int size = array.length;

        // If the target is at the beginning of the array
        if (array[0] == target) {
            return 0;
        }

        // Find the range where the target may lie
        int i = 1;
        while (i < size && array[i] <= target) {
            i *= 2;
        }

        // Perform binary search within the found range
        int result = Arrays.binarySearch(array, i / 2, Math.min(i, size), target);

        // Adjust the result if the element is not found
        return (result >= 0) ? result : -1;
    }
}

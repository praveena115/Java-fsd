package LinearSearch;
import java.util.Scanner;

public class Binary {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input array elements (assuming the array is sorted)
        System.out.print("Enter the size of the sorted array: ");
        int size = scanner.nextInt();
        int[] array = new int[size];

        System.out.println("Enter the sorted elements of the array:");
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }

        // Input the element to search
        System.out.print("Enter the element to search: ");
        int target = scanner.nextInt();

        // Perform binary search
        int index = binarySearch(array, target);

        // Display the result
        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found in the array");
        }

        scanner.close();
    }

    // Binary Search Algorithm
    private static int binarySearch(int[] array, int target) {
        int low = 0;
        int high = array.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if the element is found
            } else if (array[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; // Return -1 if the element is not found
    }
}



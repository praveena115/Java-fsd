package Section3Practice;
import java.util.LinkedList;
import java.util.Queue;

public class QueueAddRem {
    public static void main(String[] args) {
        // Create a queue
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue (enqueue)
        System.out.println("Inserting elements into the queue:");
        enqueueElement(queue, 2);
        enqueueElement(queue, 4);
        enqueueElement(queue, 6);
        enqueueElement(queue, 8);

        // Display the queue after insertion
        displayQueue(queue);

        // Remove elements from the queue (dequeue)
        System.out.println("\nRemoving elements from the queue:");
        dequeueElement(queue);
        dequeueElement(queue);

        // Display the queue after removal
        displayQueue(queue);
    }

    // Function to insert an element into the queue (enqueue)
    private static void enqueueElement(Queue<Integer> queue, int element) {
        queue.add(element);
        System.out.println("Inserted: " + element);
    }

    // Function to remove an element from the queue (dequeue)
    private static void dequeueElement(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue.");
        } else {
            int dequeuedElement = queue.poll();
            System.out.println("Removed: " + dequeuedElement);
        }
    }

    // Function to display the elements of the queue
    private static void displayQueue(Queue<Integer> queue) {
        System.out.println("Final Queue elements are:");
        if (queue.isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            for (int element : queue) {
                System.out.println(element);
            }
        }
        System.out.println();
    }
}



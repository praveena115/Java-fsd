package Section3Practice;
public class Range{
    public static long query(int[] arr, int L, int R) {
        long sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }

    public static void main(String args[]) {
        int arr[] = {3, 7, 2, 5, 8, 9};
        
        // Query 1
        System.out.println("Query 1 (0, 5): " + query(arr, 1, 4));

        // Query 2
        System.out.println("Query 2 (3, 5): " + query(arr, 4, 5));

        // Query 3
        System.out.println("Query 3 (2, 4): " + query(arr, 3, 4));
    }
}



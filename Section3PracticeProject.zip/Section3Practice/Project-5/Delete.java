package Section3Practice;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class Delete {
    private Node head;

    public Delete() {
        this.head = null;
    }

    // Function to insert a new node at the end of the linked list
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Function to delete the first occurrence of a key in the linked list
    public void Delete(int key) {
        Node current = head;
        Node prev = null;

        // Traverse the list to find the key
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If key is not present
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Remove the node containing the key
        if (prev == null) {
            // If the key is in the first node
            head = current.next;
        } else {
            // If the key is in a non-first node
            prev.next = current.next;
        }

        System.out.println("Node with key " + key + " will be deleted from the linked list.");
    }

    // Function to display the linked list
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
       Delete linkedList = new Delete();

        // Insert elements into the linked list
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(8);
        linkedList.insert(3);
        linkedList.insert(4);

        System.out.println("Original Linked List:");
        linkedList.display();

        // Delete the first occurrence of key 4
        linkedList.Delete(4);

        System.out.println("after deleting key 4:");
        linkedList.display();
    }
}

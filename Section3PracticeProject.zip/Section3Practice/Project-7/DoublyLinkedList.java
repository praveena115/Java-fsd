package Section3Practice;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class DoublyLinkedList {
    private Node head;

    public DoublyLinkedList() {
        this.head = null;
    }
    // Function to insert a new node at the end of the doubly linked list
    public void insert(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }
    // Function to traverse and display the doubly linked list in the forward direction
    public void traverseForward() {
        System.out.println("Doubly Linked List (Forward):");
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    // Function to traverse and display the doubly linked list in the backward direction
    public void traverseBackward() {
        System.out.println("Doubly Linked List (Backward):");
        Node current = findLastNode();
        while (current != null) {
            System.out.print(current.data + " ");
            current = findPreviousNode(current);
        }
        System.out.println();
    }
    // function to find the last node in the list
    private Node findLastNode() {
        Node current = head;
        while (current != null && current.next != null) {
            current = current.next;
        }
        return current;
    }
//function to find the previous node of the given node
    private Node findPreviousNode(Node node) {
        Node current = head;
        while (current != null && current.next != node) {
            current = current.next;
        }
        return current;
    }
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        doublyList.insert(1);
        doublyList.insert(2);
        doublyList.insert(3);
        doublyList.insert(4);
        // Traverse and display the doubly linked list in both directions
        doublyList.traverseForward();
        doublyList.traverseBackward();
    }
}


package Section3Practice;
import java.util.Arrays;

public class ForthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {12, 5, 8, 2, 10, 7, 3, 15}; // Replace this with your unsorted list
        System.out.println("Unsorted List:");
        printArray(unsortedList);
        int fourthSmallest = findFourthSmallestElement(unsortedList);
        System.out.println("\nThe fourth smallest element is: " + fourthSmallest);
    }
    // Function to find the fourth smallest element in an unsorted list
    private static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("The list should have at least four elements.");
            return -1; // Return a sentinel value indicating an error
        }
        //Sort the array in ascending order
        Arrays.sort(arr);
        // Return the fourth element (index 3) in the sorted array
        return arr[3];
    }
    // Function to print the elements of the array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}



package Section3Practice;
import java.util.Stack;

public class StackRemAdd {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        System.out.println("Inserting elements into the stack:");
        pushElement(stack, 1);
        pushElement(stack, 2);
        pushElement(stack, 3);
        pushElement(stack, 4);

        // Display the stack after insertion
        displayStack(stack);
        // Remove elements from the stack (pop)
        System.out.println("\nRemoving elements from the stack:");
        popElement(stack);
        popElement(stack);
        // Display the stack after removal
        displayStack(stack);
    }
    // Function to insert an element into the stack (push)
    private static void pushElement(Stack<Integer> stack, int element) {
        stack.push(element);
        System.out.println( + element);
    }

    // Function to remove an element from the stack (pop)
    private static void popElement(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty. Cannot pop.");
        } else {
            int poppedElement = stack.pop();
            System.out.println("Removed element: " + poppedElement);
        }
    }
    // Function to display the elements of the stack
    private static void displayStack(Stack<Integer> stack) {
        System.out.println(" The Stack elements are:");
        if (stack.isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            for (int i = stack.size() - 1; i >= 0; i--) {
                System.out.println(stack.get(i));
            }
        }
        System.out.println();
    }
}


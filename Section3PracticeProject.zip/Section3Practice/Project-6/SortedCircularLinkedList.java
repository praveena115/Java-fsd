package Section3Practice;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class SortedCircularLinkedList {
    private Node head;

    public SortedCircularLinkedList() {
        this.head = null;
    }
    // Function to insert a new element in a sorted circular linked list
    public void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null || newData < head.data) {
            if (head == null) {
                newNode.next = newNode; 
            } else {
                // Update the last node's next pointer
                Node last = head;
                while (last.next != head) {
                    last = last.next;
                }
                last.next = newNode;
                newNode.next = head; 
            }
            head = newNode;
        } else {
            // Case 2: Insert in the middle or at the end of the list
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }

        System.out.println("Element " + newData + "  is inserted into the circular linked list.");
    }
    // Function to display the sorted circular linked list
    public void display() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        SortedCircularLinkedList circularList = new SortedCircularLinkedList();

        // Insert elements into the sorted circular linked list
        circularList.insert(1);
        circularList.insert(2);
        circularList.insert(3);
        circularList.insert(4);

        System.out.println("Sorted Circular Linked List are:");
        circularList.display();
    }
}



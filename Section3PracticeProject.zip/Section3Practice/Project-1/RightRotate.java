package Section3Practice;
public class RightRotate{
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9}; 

        System.out.println("Original Array:");
        printArray(array);

        //Reverse the entire array
        reverseArray(array, 0, array.length - 1);
        System.out.println("\nArray after Step 1 (Reverse the entire array):");
        printArray(array);

        //Reverse the first 5 elements
        reverseArray(array, 0, 4);
        System.out.println("\nArray after Step 2 (Reverse the first 5 elements):");
        printArray(array);

        //Reverse the remaining elements
        reverseArray(array, 5, array.length - 1);
        System.out.println("\nArray after Step 3 (Reverse the remaining elements):");
        printArray(array);

        System.out.println("\nArray after right rotation by 5 steps:");
        printArray(array);
    }
    // Function to reverse the elements of the array within the given range
    private static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
    // Function to print the elements of the array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}



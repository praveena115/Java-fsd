package Section3Practice;
public class MatrixMul{
    public static void main(String[] args) {
        // Define two 2x2 matrices A and B
        int[][] matrixA = {{1, 2}, {3, 4}};
        int[][] matrixB = {{5, 6}, {7, 8}};

        System.out.println("Matrix A:");
        printMatrix(matrixA);

        System.out.println("\nMatrix B:");
        printMatrix(matrixB);

        // Multiply the matrices
        int[][] resultMatrix = multiplyMatrices(matrixA, matrixB);

        // Print the result matrix
        System.out.println("\nResult Matrix (A * B):");
        printMatrix(resultMatrix);
    }
    // Function to multiply two 2x2 matrices
    private static int[][] multiplyMatrices(int[][] A, int[][] B) {
        int rowsA = A.length;
        int colsA = A[0].length;
        int colsB = B[0].length;

        // Initialize the result matrix
        int[][] result = new int[rowsA][colsB];

        // Perform matrix multiplication
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                result[i][j] = A[i][0] * B[0][j] + A[i][1] * B[1][j];
            }
        }
        return result;
    }
    // Function to print a matrix
    private static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}



package Phase1Project;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FilesInJava{

    public static void main(String[] args) {
        // Specify the file path
        String filePath = "example.txt";

        // Create a file
        createFile(filePath);

        // Read and display the content of the file
        System.out.println("Content of the file:");
        readFromFile(filePath);

        // Update the file
        updateFile(filePath, "Updated content.");

        // Read and display the updated content of the file
        System.out.println("Updated content of the file:");
        readFromFile(filePath);

        // Delete the file
        deleteFile(filePath);
    }
    // Function to create a file
    private static void createFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            Files.createFile(path);
            System.out.println("File created successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Function to read and display the content of a file
    private static void readFromFile(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Function to update the content of a file
    private static void updateFile(String filePath, String newContent) {
        try {
            Path path = Paths.get(filePath);
            Files.write(path, newContent.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Function to delete a file
    private static void deleteFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            Files.deleteIfExists(path);
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



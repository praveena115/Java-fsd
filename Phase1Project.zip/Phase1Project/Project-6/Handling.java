package Phase1Project;
import java.util.Scanner;

public class Handling{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter a number: ");
            int number = Integer.parseInt(scanner.nextLine());

            // Division by zero exception
            int result = 10 / number;

            // ArrayIndexOutOfBoundsException
            int[] array = {1, 2, 3};
            System.out.println("Value at index 3: " + array[3]);

        } catch (NumberFormatException e) {
            // Handle the exception if the entered value is not an integer
            System.out.println("Error: Invalid input. Please enter a valid integer.");

        } catch (ArithmeticException e) {
            // Handle division by zero exception
            System.out.println("Error: Division by zero is not allowed.");

        } catch (ArrayIndexOutOfBoundsException e) {
            // Handle array index out of bounds exception
            System.out.println("Error: Index is out of bounds for the array.");

        } catch (Exception e) {
            // Catch any other unexpected exceptions
            System.out.println("Error: " + e.getMessage());

        } finally {
            // Code in the finally block will be executed regardless of whether an exception occurred or not
            scanner.close(); // Close the scanner to release resources
            System.out.println("Finally block executed.");
        }

        System.out.println("Program completed.");
    }
}

//public class Handling {

//}

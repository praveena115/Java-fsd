package Phase1Project;
//Extending Thread class
class MyThread extends Thread {
 public void run() {
     for (int i = 1; i <= 5; i++) {
         System.out.println("Extending Thread: Count " + i);
         try {
             Thread.sleep(500);
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
     }
 }
}
//Implementing Runnable interface
class MyRunnable implements Runnable {
 public void run() {
     for (int i = 1; i <= 5; i++) {
         System.out.println("Implementing Runnable: Count " + i);
         try {
             Thread.sleep(500);
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
     }
 }
}
public class ThreadImpliment {
 public static void main(String[] args) {
     //Extending Thread class
     MyThread myThread = new MyThread();
     myThread.start();

     //Implementing Runnable interface
     MyRunnable myRunnable = new MyRunnable();
     Thread thread = new Thread(myRunnable);
     thread.start();
 }
}




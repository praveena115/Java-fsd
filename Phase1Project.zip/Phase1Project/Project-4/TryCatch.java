package Phase1Project;
import java.util.Scanner;

public class TryCatch {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        try {
            // Attempt to read an integer from user input
            int number = scanner.nextInt();
            System.out.println("You entered: " + number);
        } catch (Exception e) {
            // Handle the exception if the input is not an integer
            System.out.println("Error: Invalid input. Please enter a valid integer.");
        } finally {
            // Close the scanner to release resources
            scanner.close();
        }

        System.out.println("Program completed.");
    }
}



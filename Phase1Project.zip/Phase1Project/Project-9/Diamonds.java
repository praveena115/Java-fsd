package Phase1Project;
//Common interface
interface Animal {
 void makeSound();
}

//Interface extending Animal
interface Mammal extends Animal {
 void giveBirth();
}

//Interface extending Animal
interface Bird extends Animal {
 void layEggs();
}
class Platypus implements Mammal, Bird {
 // Resolving the diamond problem by providing a specific implementation
 @Override
 public void makeSound() {
     System.out.println("Platypus sound");
 }
 @Override
 public void giveBirth() {
     System.out.println("Platypus giving birth");
 }
 @Override
 public void layEggs() {
     System.out.println("Platypus laying eggs");
 }
}
public class Diamonds {
 public static void main(String[] args) {
     Platypus platypus = new Platypus();
     platypus.makeSound();
     platypus.giveBirth();
     platypus.layEggs();
 }
}



package Phase1Project;
public class MyClass {
    private static Object lock = new Object();
    private static boolean isNotified = false;

    public static void main(String[] args) {
        Thread numberThread = new Thread(() -> printNumbers());
        Thread messageThread = new Thread(() -> waitForNotification());

        numberThread.start();
        messageThread.start();
    }

    private static void printNumbers() {
        synchronized (lock) {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Number Thread: " + i);

                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (i == 3) {
                    synchronized (lock) {
                        isNotified = true;
                        lock.notify();
                    }
                }
            }
        }
    }
    private static void waitForNotification() {
        synchronized (lock) {
            while (!isNotified) {
                try {
                    System.out.println("Message Thread: Waiting for notification");
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            System.out.println("Message Thread: Received notification");
        }
    }
}



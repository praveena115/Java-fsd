package Pillars;
//Class demonstrating encapsulation
class Person {
 // Private attributes
 private String name;
 private int age;

 // Constructor to initialize the object
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Getter method to access the private attribute 'name'
 public String getName() {
     return name;
 }

 // Setter method to modify the private attribute 'name'
 public void setName(String name) {
     this.name = name;
 }

 // Getter method to access the private attribute 'age'
 public int getAge() {
     return age;
 }

 // Setter method to modify the private attribute 'age'
 public void setAge(int age) {
     // Perform validation if needed
     if (age > 0) {
         this.age = age;
     } else {
         System.out.println("Age must be a positive value.");
     }
 }

 // Method to display information about the person
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}

public class Encapsulation {
 public static void main(String[] args) {
     // Create an object of the Person class
     Person person = new Person("kutty", 25);

     // Access and modify attributes using getter and setter methods
     System.out.println("Before Modification:");
     person.displayInfo();

     // Modify the attributes using setter methods
     person.setName("utty");
     person.setAge(30);

     System.out.println("\nAfter Modification:");
     person.displayInfo();
 }
}



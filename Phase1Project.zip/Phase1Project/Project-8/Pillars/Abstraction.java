package Pillars;
//Abstract class representing a Shape
abstract class Shape {
 // Abstract method to calculate the area (to be implemented by subclasses)
 public abstract double calculateArea();

 // Concrete method
 public void displayInfo() {
     System.out.println("This is a shape.");
 }
}

//Concrete subclass representing a Circle
class Circle extends Shape {
 // Private attribute specific to Circle
 private double radius;

 // Constructor
 public Circle(double radius) {
     this.radius = radius;
 }
 // Implementation of the abstract method to calculate the area of a circle
 @Override
 public double calculateArea() {
     return Math.PI * radius * radius;
 }
 public void displayRadius() {
     System.out.println("Radius of the circle: " + radius);
 }
}
//Concrete subclass representing a Rectangle
class Rectangle extends Shape {
 // Private attributes specific to Rectangle
 private double length;
 private double width;

 // Constructor
 public Rectangle(double length, double width) {
     this.length = length;
     this.width = width;
 }
 // Implementation of the abstract method to calculate the area of a rectangle
 @Override
 public double calculateArea() {
     return length * width;
 }
 public void displayDimensions() {
     System.out.println("Length: " + length + ",  Width: " + width);
 }
}
public class Abstraction{
 public static void main(String[] args) {
     
     Circle circle = new Circle(5.0);
     Rectangle rectangle = new Rectangle(3.0, 4.0);
     System.out.println("Circle Area: " + circle.calculateArea());
     circle.displayInfo();
     circle.displayRadius();
     System.out.println();
     System.out.println("Rectangle Area: " + rectangle.calculateArea());
     rectangle.displayInfo();
     rectangle.displayDimensions();
 }
}


package Pillars;
//Parent class (superclass)
class Animals {
 // Method in the superclass
 public void eat() {
     System.out.println("Animal is eating.");
 }
}
//Child class (subclass) inheriting from Animal
class Dog extends Animals {
 // Method in the subclass, overriding the eat method from Animal
 @Override
 public void eat() {
     System.out.println("Dog is eating.");
 }
 // Additional method specific to Dog
 public void bark() {
     System.out.println("Dog is barking.");
 }
}

public class Animal{
 public static void main(String[] args) {
     // Create an object of the subclass (Dog)
     Dog myDog = new Dog();
     // Call methods inherited from the superclass
     myDog.eat();  // Calls the overridden eat method in Dog
     // Call method specific to Dog
     myDog.bark();
 }
}





package Phase1Project;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public interface Synchronization {
	    public static void main(String[] args) {
	        // Specify the file path
	        String filePath = "example.txt";

	        // Example: Write to a file
	        writeToFile(filePath, "Hello, World!");

	        // Example: Read from a file
	        String content = readFromFile(filePath);
	        System.out.println("File content: " + content);

	        // Example: Append to a file
	        appendToFile(filePath, "\nAppending new content.");

	        // Verify the append operation
	        content = readFromFile(filePath);
	        System.out.println("Updated file content: " + content);
	    }

	    // Function to write content to a file
	    private static void writeToFile(String filePath, String content) {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
	            writer.write(content);
	            System.out.println("Write operation successful.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Function to read content from a file
	    private static String readFromFile(String filePath) {
	        StringBuilder content = new StringBuilder();
	        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
	            String line;
	            while ((line = reader.readLine()) != null) {
	                content.append(line).append("\n");
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return content.toString();
	    }

	    // Function to append content to a file
	    private static void appendToFile(String filePath, String content) {
	        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
	            writer.write(content);
	            System.out.println("Append operation successful.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}

package Phase1Project;
import java.util.Scanner;

//Custom exception class
class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class Exceptions {
 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

     try {
         System.out.print("Enter a number: ");
         int number = scanner.nextInt();

         // Throw a custom exception if the entered number is negative
         if (number < 0) {
             throw new CustomException("Negative numbers are not allowed.");
         }

         System.out.println("Square root of the number: " + Math.sqrt(number));

     } catch (CustomException ce) {
         // Catch and handle the custom exception
         System.out.println("Custom Exception: " + ce.getMessage());

     } catch (Exception e) {
         // Catch and handle other exceptions
         System.out.println("Error: " + e.getMessage());

     } finally {
         // Code in the finally block will be executed regardless of whether an exception occurred or not
         System.out.println("Finally block executed.");
         scanner.close(); // Close the scanner to release resources
     }

     System.out.println("Program completed.");
 }
}

//public class Exceptions {

//}

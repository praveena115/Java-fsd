package Projects;
import java.util.Scanner;
public class Arrays {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the size of the array: ");
	        int size = scanner.nextInt();
	        
	        int[] numbers = new int[size];

	        // Get user input for array elements
	        System.out.println("Enter the elements of the array:");
	        for (int i = 0; i < size; i++) {
	            System.out.print("Element at index " + i + ": ");
	            numbers[i] = scanner.nextInt();
	        }

	        scanner.close();

	        // Display the elements of the array
	        System.out.print("Array elements: ");
	        for (int i = 0; i < size; i++) {
	            System.out.print(numbers[i] + " ");
	        }
	        System.out.println();

	        // sum of array elements
	        int sum = 0;
	        for (int i = 0; i < size; i++) {
	            sum += numbers[i];
	        }
	        System.out.println("Sum of array elements: " + sum);

	        //maximum element in the array
	        int max = numbers[0];
	        for (int i = 1; i < size; i++) {
	            if (numbers[i] > max) {
	                max = numbers[i];
	            }
	        }
	        System.out.println("Maximum element in the array: " + max);
	    }

}

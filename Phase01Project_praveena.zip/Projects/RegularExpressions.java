package Projects;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegularExpressions {
	 public static void main(String[] args) {
	    
	        Scanner scanner = new Scanner(System.in);

	        //Validate if a string matches a specific pattern (email address)
	        System.out.print("Enter an email address: ");
	        String emailToCheck = scanner.nextLine();

	        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
	        Pattern emailValidator = Pattern.compile(emailPattern);
	        Matcher emailMatcher = emailValidator.matcher(emailToCheck);

	        if (emailMatcher.matches()) {
	            System.out.println("Valid email address: " + emailToCheck);
	        } else {
	            System.out.println("Invalid email address: " + emailToCheck);
	        }

	        //Extract mentions from a text using regular expressions
	        System.out.print("\nEnter a text with mentions: ");
	        String textWithMentions = scanner.nextLine();

	        // Define the regular expression pattern for extracting mentions
	        Pattern mentionExtractor = Pattern.compile("\\B@(\\w+)");
	        Matcher mentionMatcher = mentionExtractor.matcher(textWithMentions);

	        // Find and display all mentions in the text
	        System.out.println("\nExtracted mentions:");
	        while (mentionMatcher.find()) {
	            System.out.println(mentionMatcher.group(1));
	        }

	        scanner.close();
	    }
	

}

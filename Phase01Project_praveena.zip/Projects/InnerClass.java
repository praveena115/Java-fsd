package Projects;
import java.util.Scanner;

//Outer class
class OuterClass {
 private String outerMessage = "Hello from OuterClass";

 // Member Inner Class
 class MemberInnerClass {
     public void display() {
         System.out.println("Message from MemberInnerClass: " + outerMessage);
     }
 }

 // Static Nested Class
 static class StaticNestedClass {
     public void display() {
         System.out.println("Message from StaticNestedClass");
     }
 }

 // Method with Local Inner Class
 public void createLocalInnerClass(String localMessage) {
     // Local Inner Class
     class LocalInnerClass {
         public void display() {
             System.out.println("Message from LocalInnerClass: " + localMessage);
         }
     }

     // Create an instance of the LocalInnerClass
     LocalInnerClass localInner = new LocalInnerClass();
     localInner.display();
 }

 // Method with Anonymous Inner Class
 public void createAnonymousInnerClass() {
     // Anonymous Inner Class implementing the Runnable interface
     Runnable anonymousInner = new Runnable() {
         @Override
         public void run() {
             System.out.println("Message from Anonymous Inner Class: " + outerMessage);
         }
     };

     // Run the anonymous inner class
     anonymousInner.run();
 }
}

public class InnerClass {
 public static void main(String[] args) {
     // Create an instance of the OuterClass
     OuterClass outerObj = new OuterClass();

     // Create an instance of the MemberInnerClass
     OuterClass.MemberInnerClass memberInnerObj = outerObj.new MemberInnerClass();
     memberInnerObj.display();

     // Create an instance of the StaticNestedClass
     OuterClass.StaticNestedClass staticNestedObj = new OuterClass.StaticNestedClass();
     staticNestedObj.display();

     // Get user input for local inner class
     Scanner scanner = new Scanner(System.in);
     System.out.print("Enter a message for LocalInnerClass: ");
     String localMessage = scanner.nextLine();

     // Call the method that uses the LocalInnerClass
     outerObj.createLocalInnerClass(localMessage);

     // Call the method that uses the Anonymous Inner Class
     outerObj.createAnonymousInnerClass();

     // Close the Scanner to avoid resource leaks
     scanner.close();
 }
}


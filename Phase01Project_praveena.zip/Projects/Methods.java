package Projects;

public class Methods {
	public int add(int a, int b) {
        return a + b;
 }
 public int subtract(int a, int b) {
        return a - b;
    }

 public int multiply(int a, int b) {
        return a * b;
    }
 public double divide(int a, int b) {
        if (b != 0) {
            return (double) a / b; 
        } else {
            System.out.println("Cannot divide by zero.");
            return Double.NaN; 
        }
    }
public static void main(String[] args) {
 // Creating an instance of Method
 Methods methods = new Methods();

 // Calling methods and displaying results
 int sumResult = methods.add(5, 3);
 int differenceResult = methods.subtract(8, 4);
 int productResult = methods.multiply(6, 2);
 double divisionResult = methods.divide(10, 2);

 System.out.println("Results:");
 System.out.println("Sum: " + sumResult);
 System.out.println("Difference: " + differenceResult);
 System.out.println("Product: " + productResult);
 System.out.println("Division: " + divisionResult);

 // Verifying the divide method with edge case (division by zero)
 double divisionByZeroResult = methods.divide(5, 0);
 System.out.println("Result of division by zero: " + divisionByZeroResult);
}

}

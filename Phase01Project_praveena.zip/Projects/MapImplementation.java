package Projects;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
public class MapImplementation {
	 public static void main(String[] args) {
	        // Creating a HashMap of String keys and Integer values
	        Map<String, Integer> studentScores = new HashMap<>();

	        // Scanner for user input
	        Scanner scanner = new Scanner(System.in);

	        // Getting user input for student names and scores
	        for (int i = 0; i < 3; i++) {
	            System.out.print("Enter student name: ");
	            String name = scanner.nextLine();

	            System.out.print("Enter student score: ");
	            int score = scanner.nextInt();
	            scanner.nextLine(); 

	            studentScores.put(name, score);
	        }

	        // Displaying key-value pairs using Iterator
	        System.out.println("\nStudent Scores are");
	        Iterator<Map.Entry<String, Integer>> iterator = studentScores.entrySet().iterator();
	        while (iterator.hasNext()) {
	            Map.Entry<String, Integer> entry = iterator.next();
	            System.out.println(entry.getKey() + " : " + entry.getValue());
	        }
	        scanner.close();
	    }
	

}

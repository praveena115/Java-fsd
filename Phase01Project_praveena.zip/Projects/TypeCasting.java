package Projects;
import java.util.Scanner;
public class TypeCasting {
	 public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		
		 System.out.print("Enter an integer value: ");
	        int intValue = scanner.nextInt();
	        
	        double doubleValue = intValue; 
	        System.out.println("\nImplicit Type Casting:");
	        System.out.println("int value: " + intValue);
	        System.out.println("double value after implicit casting: " + doubleValue);
	        System.out.println();

	        System.out.print("Enter a double value: ");
	        double anotherDoubleValue = scanner.nextDouble();
	        int anotherIntValue = (int) anotherDoubleValue; 

	        System.out.println("Explicit Type Casting:");
	        System.out.println("double value: " + anotherDoubleValue);
	        System.out.println("int value after explicit casting: " + anotherIntValue);
	        scanner.close();
	 }
	
	

}

package Projects;
import java.util.Scanner;
public class Strings {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();
        scanner.close();

        // Convert the string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(userInput);
        System.out.println("StringBuffer: " + stringBuffer);

        // Convert the string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(userInput);
        System.out.println("StringBuilder: " + stringBuilder);
    }
	
}

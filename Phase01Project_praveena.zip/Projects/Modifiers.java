package Projects;

public class Modifiers {
	 public String publicName = "Public Person";

	    protected String protectedName = "Protected Person";
	    // Default (Package-Private) variable
	    String defaultName = "Default Person";
	    // Private variable
	    private String privateName = "Private Person";
	    // Public method
	    public void publicMethod() {
	        System.out.println("Public method called.");
	    }
	    // Protected method
	    protected void protectedMethod() {
	        System.out.println("Protected method called.");
	    }
	    // Default (Package-Private) method
	    void defaultMethod() {
	        System.out.println("Default method called.");
	    }
	    // Private method
	    private void privateMethod() {
	        System.out.println("Private method called.");
	    }
	
	    public static void main(String[] args) {
	        // Create an instance of the Person class
	        Modifiers Modifiers = new Modifiers();

	        // Accessing public members
	        System.out.println("Public variable: " + Modifiers.publicName);
	        Modifiers.publicMethod();

	        // Accessing protected members (within the same package)
	        System.out.println("Protected variable: " + Modifiers.protectedName);
	        Modifiers.protectedMethod();

	        // Accessing default (Package-Private) members (within the same package)
	        System.out.println("Default variable: " + Modifiers.defaultName);
	        Modifiers.defaultMethod();

	       
	    }
	}



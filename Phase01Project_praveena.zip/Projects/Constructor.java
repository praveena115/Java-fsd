package Projects;

public class Constructor {
	 private String name;
	    private int age;

	    // Default constructor
	    public Constructor() {
	        this.name = "Unknown";
	        this.age = 0;
	        System.out.println("Object created with default values.");
	    }

	    // Parameterized constructor
	    public Constructor(String name, int age) {
	        this.name = name;
	        this.age = age;
	        System.out.println("Object created with provided values.");
	    }

	    // Copy constructor
	    public Constructor(Constructor otherObject) {
	        this.name = otherObject.name;
	        this.age = otherObject.age;
	        System.out.println("Object created by copying another object.");
	    }

	    public void displayDetails() {
	        System.out.println("Object Details:");
	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        // Creating instances using different constructors
	        Constructor defaultObject = new Constructor();
	        Constructor parameterizedObject = new Constructor("kutty", 25);

	        // Displaying details of objects
	        System.out.println("Details of Default Object:");
	        defaultObject.displayDetails();

	        System.out.println("Details of Parameterized Object:");
	        parameterizedObject.displayDetails();

	        // Creating a copy of the parameterized object using the copy constructor
	        Constructor copiedObject = new Constructor(parameterizedObject);

	        // Displaying details of the copied object
	        System.out.println("Details of Copied Object:");
	        copiedObject.displayDetails();
	    }
	

}

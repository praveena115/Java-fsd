package Projects;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;
public class Collections {
	public static void main(String[] args) {
      
        // Creating an ArrayList of Strings
        ArrayList<String> Animals = new ArrayList<>();

        // Adding elements to the ArrayList
        Animals.add("Cow");
        Animals.add("Dog");
        Animals.add("Cat");

        // Displaying elements using enhanced for loop
        System.out.print("Animals in ArrayList are: ");
        for (String language : Animals) {
            System.out.print(language + " ");
        }
        System.out.println("\n");


        // Creating a HashSet of integers
        HashSet<Integer> numbersSet = new HashSet<>();

        // Adding elements to the HashSet
        numbersSet.add(10);
        numbersSet.add(20);
        numbersSet.add(30);

        // Displaying elements using Iterator
        System.out.print("Numbers in HashSet are: ");
        Iterator<Integer> iterator = numbersSet.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println("\n");

        // Creating a HashMap of String keys and Integer values
        HashMap<String, Integer> studentScores = new HashMap<>();

        // Adding key-value pairs to the HashMap
        studentScores.put("Alice", 85);
        studentScores.put("Bob", 92);
        studentScores.put("Charlie", 78);

        // Displaying key-value pairs using Iterator
        System.out.println("Student Scores in HashMap:");
        Iterator<HashMap.Entry<String, Integer>> hashMapIterator = studentScores.entrySet().iterator();
        while (hashMapIterator.hasNext()) {
            HashMap.Entry<String, Integer> entry = hashMapIterator.next();
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }
    }
	
	

}
